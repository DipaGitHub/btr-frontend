import { serviceData } from '../../data/siteData'
import { go } from '../../utils/navigation'
import { Logo } from '../shared/SiteComponents'

export function Footer() {
  return <footer className="footer"><div className="footer-top"><div><Logo light /><p>Transforming ideas into digital excellence. Elevate your online presence with thoughtful, strategic digital experiences.</p></div><div><h4>Services</h4>{serviceData.map(service => <button key={service.slug} onClick={() => go(`/services/${service.slug}`)}>{service.title}</button>)}</div><div><h4>Company</h4><button onClick={() => go('/about')}>About us</button><button onClick={() => go('/portfolio')}>Portfolio</button><button onClick={() => go('/contact')}>Contact</button></div><div><h4>Support</h4><a href="tel:+918282833539">+91 82828 33539</a><a href="mailto:info@btrcommunication.com">info@btrcommunication.com</a><span>Kolkata · India</span></div></div><div className="footer-bottom">© 2026 BTR Communication. All rights reserved.</div></footer>
}
