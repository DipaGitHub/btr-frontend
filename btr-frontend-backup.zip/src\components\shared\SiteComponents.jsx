import { ArrowUpRight } from 'lucide-react'
import { go } from '../../utils/navigation'

export function Logo({ light = false }) {
  return <div className={`logo ${light ? 'logo-light' : ''}`}><span>BTR</span><small>COMMUNICATION</small></div>
}

export function Banner({ title, eyebrow = 'WHO WE ARE' }) {
  return <section className="page-banner"><span>{eyebrow}</span><h1>{title}</h1><small>Home&nbsp; / &nbsp;{title}</small></section>
}

export function SectionHeading({ kicker, title }) {
  return <div className="section-heading"><span className="section-kicker">{kicker}</span><h2>{title}</h2><p>Focused expertise for every stage of your digital journey.</p></div>
}

export function ServiceCard({ service }) {
  return (
    <article className="service-card" onClick={() => go(`/services/${service.slug}`)}>
      {/* <div className="service-icon">✦</div> */}
      <h3>{service.title || service.name}</h3>
      <p>{service.detail || service.description}</p>
      <button className="card-link">Learn more <ArrowUpRight size={15} /></button>
    </article>
  )
}

export function ProjectCard({ project }) {
  const openProject = () => go(`/portfolio/${project.id}`)

  const bgStyle = project.thumbnail ? {
    backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.7)), url(${project.thumbnail})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center'
  } : {}

  return (
    <article 
      className="project-card" 
      role="link" 
      tabIndex="0" 
      onClick={openProject} 
      onKeyDown={event => { if (event.key === 'Enter' || event.key === ' ') openProject() }}
    >
      <div className={`project-art ${project.className || ''}`} style={bgStyle}>
        <span>{project.type || 'Web Development'}</span>
        <strong>{project.cardTitle || project.title}</strong>
      </div>
      <div className="project-meta">
        <span>{project.type || 'Web Development'}</span>
        <h3>{project.cardTitle || project.title}</h3>
        <p>{project.description ? project.description.slice(0, 110) + '...' : 'A considered digital experience designed to help a growing business turn visits into momentum.'}</p>
        <button className="card-link" onClick={event => { event.stopPropagation(); openProject() }}>
          View details <ArrowUpRight size={15} />
        </button>
      </div>
    </article>
  )
}

export function Stats() {
  return <section className="stats stats-band"><b>350+<small>Projects Completed</small></b><b>14+<small>Team Members</small></b><b>9+<small>Years Experience</small></b><b>230+<small>Happy Clients</small></b></section>
}