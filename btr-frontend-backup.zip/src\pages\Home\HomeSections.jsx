import { API_BASE_URL } from '../../utils/apiConfig';
import { useEffect, useState } from 'react'
import { ArrowUpRight, ChevronDown, Code2, MonitorCog } from 'lucide-react'
import { go } from '../../utils/navigation'

const fallbackReviews = [
  { initials: 'MC', name: 'Michael Chen', role: 'CTO · GLOBAL SOLUTIONS INC', rating: 5, text: 'Outstanding service and innovative solutions. They truly understand business technology.' },
  { initials: 'ER', name: 'Emily Rodriguez', role: 'DIRECTOR · INNOVATION LABS', rating: 5, text: 'A strategic partner that delivers results. Highly recommended for digital transformation.' },
  { initials: 'DL', name: 'David Lee', role: 'VP OF OPERATIONS · FUTURE DYNAMICS', rating: 4, text: 'The team exceeded all expectations. We saw a 30% increase in efficiency within the first quarter.' },
  { initials: 'SJ', name: 'Sarah Johnson', role: 'CEO · TECHCORP INDUSTRIES', rating: 5, text: 'Geemadhura Innovations transformed our business operations. Their expertise and dedication are unmatched.' },
  { initials: 'DC', name: 'Debraj Chakraborty', role: 'SR SOFTWARE DEVELOPER · GOOGLE', rating: 4, text: 'Great team culture and technical expertise in execution.' },
  { initials: 'SK', name: 'Shovan Kantal', role: 'DEVELOPER · BTR TECH', rating: 4, text: 'Clear communication and fast delivery of product requirements.' },
]

const fallbackFaqs = [
  { id: 8, qus: 'What is the total cost?', answers: 'Every project is scoped around its goals, complexity, timeline, and support requirements. We provide a clear quote before work begins.' },
  { id: 7, qus: 'Do you guarantee results?', answers: 'We set practical goals, measure performance, and optimize continuously. Exact outcomes depend on the market, audience, and project scope.' },
  { id: 6, qus: 'Can you help with SEO too?', answers: 'Yes. We support technical SEO, content strategy, on-page optimization, local visibility, and performance reporting.' },
  { id: 5, qus: 'Is there WhatsApp support?', answers: 'Yes. Our team provides convenient WhatsApp communication throughout active projects and support periods.' },
  { id: 4, qus: 'Do you offer technical support?', answers: 'Yes. Flexible post-launch support covers maintenance, updates, performance, security, and future improvements.' },
  { id: 3, qus: 'How long does a website take?', answers: 'Most websites move through discovery, design, development, testing, and launch within an agreed project timeline.' },
  { id: 2, qus: 'What if my requirements change?', answers: 'We review the new requirement with you, explain any timeline or cost impact, and agree on the change before proceeding.' },
  { id: 1, qus: 'Can you work with an existing website?', answers: 'Absolutely. We can audit, redesign, optimize, maintain, or extend an existing website and its technology stack.' },
]

export function DigitalExcellence() {
  return (
    <section className="digital-excellence">
      <div className="digital-grid" aria-hidden="true">
        <Code2 />
        <MonitorCog />
      </div>
      <div className="digital-copy">
        <span className="section-kicker">BUILT FOR PROGRESS</span>
        <h2>Driving Digital Excellence:<br />Unleash the Power of BTR Communication</h2>
        <p>BTR Communication provides professional digital solutions to help businesses establish and grow their online presence. Our services include website design and development, e-commerce solutions, UI/UX design, website maintenance, and performance optimization.</p>
        <button className="button" onClick={() => go('/about')}>Discover more <ArrowUpRight size={16} /></button>
      </div>
    </section>
  )
}

export function ServicesSection() {
  const [services, setServices] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch(`${API_BASE_URL}/api/services`)
      .then((res) => res.json())
      .then((json) => {
        if (json.data && Array.isArray(json.data)) {
          const baseUrl = API_BASE_URL
          const formatted = json.data.map((service) => {
            let imageUrl = service.image_url || service.icon || ''
            if (imageUrl.startsWith('/')) {
              imageUrl = `${baseUrl}${imageUrl}`
            }
            return {
              id: service.id,
              title: service.title || service.name,
              description: service.description || service.short_description,
              image: imageUrl,
            }
          })
          setServices(formatted)
        }
        setLoading(false)
      })
      .catch((err) => {
        console.error('Failed to fetch services:', err)
        setLoading(false)
      })
  }, [])

  return (
    <section className="home-services section-dark" style={{ padding: '60px 20px' }}>
      <SectionTitle
        eyebrow="OUR SERVICES"
        title="Focused expertise for every stage of your digital journey."
      />
      {!loading && services.length > 0 && (
        <div
          className="services-grid"
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '24px',
            maxWidth: '1140px',
            margin: '40px auto 0 auto',
          }}
        >
          {services.map((service) => (
            <article
              key={service.id}
              className="service-card"
              style={{
                backgroundColor: '#11141c',
                borderRadius: '12px',
                border: '1px solid rgba(255, 255, 255, 0.08)',
                padding: '32px 24px',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'flex-start',
              }}
            >
              <div
                className="service-icon-wrapper"
                style={{
                  width: '48px',
                  height: '48px',
                  marginBottom: '20px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                {service.image ? (
                  <img
                    src={service.image}
                    alt={service.title}
                    style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                    onError={(e) => {
                      e.currentTarget.style.display = 'none'
                    }}
                  />
                ) : (
                  <Code2 color="#ff4d4d" size={32} />
                )}
              </div>
              <h3 style={{ color: '#ffffff', fontSize: '20px', marginBottom: '12px' }}>
                {service.title}
              </h3>
              <p style={{ color: '#a0a6b5', fontSize: '14px', lineHeight: '1.6' }}>
                {service.description}
              </p>
            </article>
          ))}
        </div>
      )}
    </section>
  )
}

export function Testimonials() {
  const [reviews, setReviews] = useState(fallbackReviews)
  const [loading, setLoading] = useState(true)
  const [startIndex, setStartIndex] = useState(0)
  const [isPaused, setIsPaused] = useState(false)

  useEffect(() => {
    fetch(`${API_BASE_URL}/api/testimonials`)
      .then((res) => res.json())
      .then((json) => {
        if (json.data && Array.isArray(json.data) && json.data.length > 0) {
          const baseUrl = API_BASE_URL

          const formatted = json.data.map((item) => {
            const initials = item.client_name
              ? item.client_name
                  .split(' ')
                  .map((n) => n[0])
                  .join('')
                  .toUpperCase()
                  .slice(0, 2)
              : 'CL'

            let imageUrl = item.image_url || ''
            if (imageUrl.startsWith('/public')) {
              imageUrl = `${baseUrl}${imageUrl}`
            }

            const role = [item.client_position, item.client_company]
              .filter(Boolean)
              .join(' • ')
              .toUpperCase()

            return {
              id: item.client_name + item.client_company,
              initials,
              name: item.client_name,
              role: role || 'VALUED CLIENT',
              rating: Number(item.review_stars) || 5,
              text: item.comment,
              image: imageUrl,
            }
          })

          setReviews(formatted)
        }
        setLoading(false)
      })
      .catch((err) => {
        console.error('Failed to fetch testimonials:', err)
        setLoading(false)
      })
  }, [])

  useEffect(() => {
    if (isPaused || reviews.length <= 3) return

    const interval = setInterval(() => {
      setStartIndex((prevIndex) => (prevIndex + 1) % reviews.length)
    }, 3000)

    return () => clearInterval(interval)
  }, [isPaused, reviews.length])

  const visibleReviews = Array.from({ length: Math.min(3, reviews.length) }, (_, i) => {
    return reviews[(startIndex + i) % reviews.length]
  })

  return (
    <section className="home-testimonials section-dark" style={{ padding: '60px 20px', backgroundColor: '#090a0f' }}>
      <SectionTitle eyebrow="CLIENT STORIES" title="Client Feedback & Reviews" />

      {!loading && reviews.length > 0 && (
        <div
          className="review-carousel-wrapper"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          style={{ maxWidth: '1140px', margin: '40px auto 0 auto' }}
        >
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: '24px',
            }}
          >
            {visibleReviews.map((review, idx) => (
              <article
                key={`${review.id || review.name}-${startIndex}-${idx}`}
                style={{
                  backgroundColor: '#11141c',
                  borderRadius: '12px',
                  border: '1px solid rgba(255, 255, 255, 0.08)',
                  padding: '36px 28px',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center',
                  minHeight: '340px',
                  justifyContent: 'space-between',
                  transition: 'all 0.5s ease-in-out',
                }}
              >
                <div
                  style={{
                    width: '64px',
                    height: '64px',
                    borderRadius: '50%',
                    overflow: 'hidden',
                    marginBottom: '16px',
                    backgroundColor: '#1c202d',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 'bold',
                    color: '#fff',
                    border: '2px solid rgba(255, 255, 255, 0.1)',
                  }}
                >
                  {review.image ? (
                    <img
                      src={review.image}
                      alt={review.name}
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                      onError={(e) => {
                        e.currentTarget.style.display = 'none'
                      }}
                    />
                  ) : (
                    review.initials
                  )}
                </div>

                <div style={{ color: '#ffb400', fontSize: '18px', letterSpacing: '2px', marginBottom: '16px' }}>
                  {'★'.repeat(review.rating)}
                  <span style={{ color: 'rgba(255,255,255,0.2)' }}>
                    {'★'.repeat(Math.max(0, 5 - review.rating))}
                  </span>
                </div>

                <p
                  style={{
                    color: '#a0a6b5',
                    fontSize: '14px',
                    lineHeight: '1.6',
                    marginBottom: '24px',
                    flexGrow: 1,
                  }}
                >
                  "{review.text}"
                </p>

                <div>
                  <strong style={{ display: 'block', color: '#ffffff', fontSize: '16px', marginBottom: '6px' }}>
                    {review.name}
                  </strong>
                  <small
                    style={{
                      color: '#ff4d4d',
                      fontSize: '11px',
                      fontWeight: '700',
                      letterSpacing: '0.8px',
                      textTransform: 'uppercase',
                    }}
                  >
                    {review.role}
                  </small>
                </div>
              </article>
            ))}
          </div>

          {reviews.length > 3 && (
            <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginTop: '32px' }}>
              {reviews.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setStartIndex(idx)}
                  aria-label={`Go to slide ${idx + 1}`}
                  style={{
                    width: startIndex === idx ? '24px' : '8px',
                    height: '8px',
                    borderRadius: '4px',
                    backgroundColor: startIndex === idx ? '#ff4d4d' : 'rgba(255, 255, 255, 0.2)',
                    border: 'none',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease',
                  }}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </section>
  )
}

export function FaqSection() {
  const [faqsList, setFaqsList] = useState(fallbackFaqs)
  const [loading, setLoading] = useState(true)
  const [open, setOpen] = useState(null)

  useEffect(() => {
    fetch(`${API_BASE_URL}/api/faqs`)
      .then((res) => res.json())
      .then((json) => {
        if (json.status === 200 && Array.isArray(json.data) && json.data.length > 0) {
          setFaqsList(json.data)
        }
        setLoading(false)
      })
      .catch((err) => {
        console.error('Failed to fetch FAQs:', err)
        setLoading(false)
      })
  }, [])

  return (
    <section className="home-faq section-dark">
      <SectionTitle
        eyebrow="FREQUENTLY ASKED QUESTIONS"
        title="Your Questions, Our Expertise."
        subtitle="We've compiled answers to the most common questions about our services, process, and commitment to your success."
      />
      {!loading && (
        <div className="faq-grid">
          {faqsList.map((faq, index) => {
            const question = faq.qus || faq[0]
            const answer = faq.answers || faq[1]
            const id = faq.id || index

            return (
              <article className={open === index ? 'open' : ''} key={id}>
                <button aria-expanded={open === index} onClick={() => setOpen(open === index ? null : index)}>
                  <span>{question}</span>
                  <ChevronDown size={18} />
                </button>
                <div className="faq-answer">
                  <p>{answer}</p>
                </div>
              </article>
            )
          })}
        </div>
      )}
    </section>
  )
}

export function LatestInsights() {
  const [blogs, setBlogs] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/api/blogs`)
        const data = await response.json()
        
        if (data.success && Array.isArray(data.data)) {
          const formattedBlogs = data.data.map(blog => ({
            id: blog.id,
            title: blog.title,
            description: blog.short_description,
            publish_date: blog.publish_date,
            banner_image: blog.banner_image,
            tags: blog.tags.split(',').map(tag => tag.trim()),
            author: blog.author,
            formattedDate: new Date(blog.publish_date).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              year: 'numeric'
            })
          }))
          setBlogs(formattedBlogs)
        }
        setLoading(false)
      } catch (err) {
        console.error('Error fetching blogs:', err)
        setLoading(false)
      }
    }

    fetchBlogs()
  }, [])

  return (
    <section className="latest-insights section-dark">
      <SectionTitle 
        eyebrow="FROM OUR BLOG" 
        title="Latest Insights" 
        subtitle="Ideas, guidance, and digital perspectives from our team." 
      />
      
      {!loading && blogs.length > 0 && (
        <div className="insight-grid">
          {blogs.slice(0, 3).map((blog) => (
            <article 
              key={blog.id} 
              onClick={() => go(`/blogs/${blog.id}`)}
              style={{ cursor: 'pointer' }}
            >
              <div 
                className="insight-art"
                style={{
                  backgroundImage: blog.banner_image ? `url(${API_BASE_URL}${blog.banner_image})` : 'none',
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                  minHeight: '200px',
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'center',
                  alignItems: 'center',
                  color: 'white',
                  textShadow: '0 2px 4px rgba(0,0,0,0.8)',
                  position: 'relative',
                  padding: '20px',
                  borderRadius: '10px',
                  marginBottom: '20px'
                }}
              >
                <div style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  backgroundColor: 'rgba(0,0,0,0.4)',
                  borderRadius: '10px'
                }}></div>
                <div style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
                  <span style={{ fontSize: '1.5rem', letterSpacing: '5px' }}>✦ · ✦ · ✦</span>
                  <strong style={{ display: 'block', marginTop: '10px', fontSize: '1.2rem' }}>
                    {blog.title}
                  </strong>
                </div>
              </div>
              <div className="insight-meta">
                <span>{blog.tags[0] || 'BLOG'}</span>
                <small>{blog.formattedDate}</small>
              </div>
              <h3>{blog.title}</h3>
              <p>{blog.description}</p>
              <button onClick={(e) => {
                e.stopPropagation()
                go(`/blogs/${blog.id}`)
              }}>
                Read article <ArrowUpRight size={14} />
              </button>
            </article>
          ))}
        </div>
      )}

      {!loading && blogs.length === 0 && (
        <div style={{ textAlign: 'center', padding: '40px', color: '#a0a6b5' }}>
          No blog posts available
        </div>
      )}
    </section>
  )
}

function SectionTitle({ eyebrow, title, subtitle }) {
  return (
    <div className="home-section-title">
      <span>{eyebrow}</span>
      <h2>{title}</h2>
      {subtitle && <p>{subtitle}</p>}
    </div>
  )
}