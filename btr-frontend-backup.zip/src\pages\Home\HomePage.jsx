import { API_BASE_URL } from '../../utils/apiConfig';
import { useState, useEffect } from 'react'
import { ArrowUpRight, Play } from 'lucide-react'
import { projects as fallbackProjects, serviceData as fallbackServices } from '../../data/siteData'
import { go } from '../../utils/navigation'
import { Logo, ProjectCard, SectionHeading, ServiceCard } from '../../components/shared/SiteComponents'
import { DigitalExcellence, FaqSection, LatestInsights, Testimonials } from './HomeSections'

// Helper to resolve clean Google / Modern SVG Icons based on service name
function getServiceGoogleIcon(serviceName = '') {
  const name = serviceName.toLowerCase()
  if (name.includes('web') || name.includes('code')) {
    return 'https://fonts.gstatic.com/s/i/productlogos/chrome/v9/web-64dp/1x/web_64dp.png'
  }
  if (name.includes('graphic') || name.includes('design')) {
    return 'https://fonts.gstatic.com/s/i/short-term/release/materialsymbolsoutlined/palette/default/48px.svg'
  }
  if (name.includes('ui') || name.includes('ux')) {
    return 'https://fonts.gstatic.com/s/i/short-term/release/materialsymbolsoutlined/devices/default/48px.svg'
  }
  if (name.includes('seo') || name.includes('search')) {
    return 'https://fonts.gstatic.com/s/i/short-term/release/materialsymbolsoutlined/search/default/48px.svg'
  }
  return 'https://fonts.gstatic.com/s/i/short-term/release/materialsymbolsoutlined/widgets/default/48px.svg'
}

function TechMarquee() {
  const [updates, setUpdates] = useState([])

  useEffect(() => {
    fetch(`${API_BASE_URL}/api/latestUpdates`)
      .then((res) => res.json())
      .then((json) => {
        if (json.success && Array.isArray(json.data)) {
          setUpdates(json.data)
        }
      })
      .catch((err) => console.error('Failed to fetch marquee items:', err))
  }, [])

  if (updates.length === 0) return null

  const marqueeList = [...updates, ...updates]

  return (
    <section className="tech-marquee-wrapper" style={{ display: 'flex', alignItems: 'center', backgroundColor: '#0b0c10', overflow: 'hidden' }}>
      <div 
        className="marquee-label" 
        style={{
          backgroundColor: '#e52e2e',
          color: '#ffffff',
          fontWeight: '700',
          padding: '12px 24px',
          borderTopRightRadius: '16px',
          borderBottomRightRadius: '16px',
          zIndex: 2,
          whiteSpace: 'nowrap',
          flexShrink: 0
        }}
      >
        Updates
      </div>

      <div className="tech-marquee" aria-label="Our updates" style={{ flexGrow: 1, overflow: 'hidden' }}>
        <div className="marquee-track">
          {marqueeList.map((item, index) => (
            <span 
              key={`${item.id}-${index}`} 
              onClick={() => go(`/updates/${item.id}`)}
              style={{ cursor: 'pointer' }}
            >
              {item.title}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}

export function HomePage({ onApply }) {
  const [services, setServices] = useState(fallbackServices)
  const [portfolioList, setPortfolioList] = useState(fallbackProjects)

  // Fetch Services API
  useEffect(() => {
    fetch(`${API_BASE_URL}/api/services`)
      .then((res) => res.json())
      .then((json) => {
        if (json.data && Array.isArray(json.data)) {
          const formatted = json.data.map((item) => {
            let plainText = ''
            if (item.service_description_text) {
              const parser = new DOMParser()
              const doc = parser.parseFromString(item.service_description_text, 'text/html')
              plainText = doc.body.textContent || doc.body.innerText || ''
              plainText = plainText.replace(/\s+/g, ' ').trim()
              if (plainText.length > 130) {
                plainText = plainText.slice(0, 130) + '...'
              }
            }

            const iconUrl = getServiceGoogleIcon(item.name)

            return {
              ...item,
              title: item.name,
              name: item.name,
              slug: item.slug,
              image: iconUrl,
              image_url: iconUrl,
              icon: iconUrl,
              description: plainText,
              detail: plainText,
            }
          })

          setServices(formatted)
        }
      })
      .catch((err) => console.error('Failed to fetch dynamic services:', err))
  }, [])

  // Fetch Portfolio API
  useEffect(() => {
    fetch(`${API_BASE_URL}/api/portfolio`)
      .then((res) => res.json())
      .then((json) => {
        if (json.data && Array.isArray(json.data)) {
          const baseUrl = API_BASE_URL
          const formatted = json.data.map((item) => ({
            id: item.id,
            title: item.title,
            cardTitle: item.title,
            type: 'Web Development',
            description: item.description,
            thumbnail: item.thumbnail_url ? `${baseUrl}${item.thumbnail_url}` : '',
            logo: item.logo_url ? `${baseUrl}${item.logo_url}` : '',
            projectUrl: item.project_url,
            className: 'portfolio-dynamic-item'
          }))
          setPortfolioList(formatted)
        }
      })
      .catch((err) => console.error('Failed to fetch dynamic portfolio:', err))
  }, [])

  return (
    <>
      <section className="hero section-dark">
        <div className="hero-copy">
          <div className="eyebrow">BTR COMMUNICATION</div>
          <h1>Helping businesses turn <em>ideas into impact.</em></h1>
          <p>We create digital experiences that make ambitious brands easier to find, easier to trust, and impossible to forget.</p>
          <div className="hero-actions">
            <button className="button" onClick={onApply}>
              Launch a project <ArrowUpRight size={16} />
            </button>
            <button className="text-link" onClick={() => go('/portfolio')}>
              <Play size={14} /> View our work
            </button>
          </div>
        </div>
        <div className="orbit-art">
          <div className="orbit"></div>
          <div className="orbit orbit-two"></div>
          <div className="orbit-center"><Logo light /></div>
          <div className="orbit-nodes">
            {['Airport Taxi', 'Shopping', 'Code', 'DNS', 'Food', 'Database', 'Cloud', 'API', 'Psychology'].map((label, index) => (
              <span className={`orbit-node node-${index}`} key={label}>{label}</span>
            ))}
          </div>
        </div>
      </section>

      <TechMarquee />

      <section className="section-dark home-intro">
        <div>
          <span className="section-kicker">WHY BTR</span>
          <h2>We make digital <em>work harder.</em></h2>
          <p>We are a full-service digital agency blending thoughtful strategy, standout creative, and reliable technology.</p>
        </div>
        <div className="stats">
          <b>350+<small>Projects completed</small></b>
          <b>14+<small>Team members</small></b>
          <b>9+<small>Years experience</small></b>
          <b>230+<small>Happy clients</small></b>
        </div>
      </section>

      <section className="section-dark services">
        <SectionHeading kicker="WHAT WE OFFER" title={<>Our professional <em>services.</em></>} />
        <div className="service-grid">
          {services.map((service) => (
            <div 
              key={service.slug || service.id} 
              className="service-card-wrapper" 
              style={{
                display: 'flex',
                flexDirection: 'column',
                gap: '12px'
              }}
            >
              <ServiceCard service={service} />
            </div>
          ))}
        </div>
      </section>

      <section className="section-dark process">
        <SectionHeading kicker="HOW WE WORK" title={<>Our process.</>} />
        <div className="process-line">
          {['Discovery', 'Planning', 'Creation', 'Growth'].map((item, index) => (
            <article className="process-card" key={item}>
              <b>0{index + 1}</b>
              <h3>{item}</h3>
              <span>{['Research & Strategy', 'Wireframe & Flow', 'Design & Develop', 'Launch & Optimize'][index]}</span>
              <p>We bring clarity to the next step and build momentum through every detail.</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section-dark portfolio">
        <SectionHeading kicker="SELECTED WORK" title={<>Projects that speak <em>for themselves.</em></>} />
        <div className="project-grid">
          {portfolioList.map((project) => (
            <ProjectCard key={project.id || project.title} project={project} />
          ))}
        </div>
        <button className="view-all-portfolio" onClick={() => go('/portfolio')}>
          View All Portfolio <ArrowUpRight size={15} />
        </button>
      </section>

      <DigitalExcellence />
      <Testimonials />
      <FaqSection />
      <LatestInsights />

      <section className="section-dark contact-cta">
        <div>
          <span className="section-kicker">LET&apos;S TALK</span>
          <h2>Ready to make your <em>next move?</em></h2>
        </div>
        <button className="button button-light" onClick={onApply}>
          Start a conversation <ArrowUpRight size={17} />
        </button>
      </section>
    </>
  )
}